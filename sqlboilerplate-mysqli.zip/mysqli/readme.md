# SQL Boilerplate :: MySQLi

Hier zie je de connectie en uitvoering van de meest voorkomende queries in MySQLi. De manual over MySQLi is hier te vinden: [MySQLi](http://php.net/mysqli). 

MySQLi kan je op 2 manieren gebruiken. Via de procedurele methode (gewoon met functies) of via de MySQLi class. Ik raad aan de class te gebruiken, aangezien MySQL daarvoor gemaakt is.
