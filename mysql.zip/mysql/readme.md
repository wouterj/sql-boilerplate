# SQL Boilerplate :: MySQL

Hier zie je de connectie en uitvoering van de meest voorkomende queries in MySQL. De manual over MySQL is hier te vinden: [MySQL](http://php.net/mysql). De homepagina is hier te vinden: [MySQL.com](http://www.mysql.com).

 > **Waarschuwing**
 > De MySQL_* functies gaan verdwijnen uit PHP. Het is raadzaam om over te stappen op MySQLi of PDO.
